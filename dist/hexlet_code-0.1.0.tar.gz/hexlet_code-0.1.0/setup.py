# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'check if you can go to 3rd grade',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AidDeathLord/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AidDeathLord/python-project-49/actions)\n\n### Maintainability:\n(<a href="https://codeclimate.com/github/AidDeathLord/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/697cc4e6546ebe8ef998/maintainability" /></a>)\n\n    Brain-games - this is a set of intelligent console games.\n    To install you will need pip. Download the repository from Git-hub and run the command - make install.\n    To win the games you need to answer three questions correctly.\n    First game in Brain-games - Even-Odd. Enter to win yes, if the number is even and no - if odd. To run, you need to enter the command in the terminal brain-even.\n### Brain-even and install:\n([![asciicast](https://asciinema.org/a/5PhtkWPISVIC4GEUM2Vlg85g1.svg)](https://asciinema.org/a/5PhtkWPISVIC4GEUM2Vlg85g1))\n\n    Second game  - calculator. Here you will need to correctly enter the result of arithmetic expressions.\n    Enter the command to run brain-calc.\n### Brain-calc:\n([![asciicast](https://asciinema.org/a/l2TuoatHFc4Yz9flfU0PNDJek.svg)](https://asciinema.org/a/l2TuoatHFc4Yz9flfU0PNDJek))\n\n    Next game - GCD. Calculate the greatest common divisor for two numbers. \n    Run command - brain-gcd.\n### Brain-gcd:\n([![asciicast](https://asciinema.org/a/W8M5Bzib9COc2rj7fJPyXMLnw.svg)](https://asciinema.org/a/W8M5Bzib9COc2rj7fJPyXMLnw))\n\n    In brain-progression you need to enter the missing number in progress.\n### Brain-progression:\n([![asciicast](https://asciinema.org/a/DDGOirXvy8WVJ9D5Mf9Kjz80P.svg)](https://asciinema.org/a/DDGOirXvy8WVJ9D5Mf9Kjz80P))\n\n    And last game - this brain-prime. To win, indicate whether the number in the task is prime.\n### Brain-prime:\n([![asciicast](https://asciinema.org/a/Ex4wKVcW7cNlSRcqG1HqaMvnk.svg)](https://asciinema.org/a/Ex4wKVcW7cNlSRcqG1HqaMvnk))',
    'author': 'Ihar Kostyuchik',
    'author_email': 'kostyuchik22@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/AidDeathLord/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
