# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'check if you can go to 3rd grade',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AidDeathLord/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AidDeathLord/python-project-49/actions)\n\n### Maintainability:\n(<a href="https://codeclimate.com/github/AidDeathLord/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/697cc4e6546ebe8ef998/maintainability" /></a>)\n\n### Asciinema\n### Brain-even and install:\n(https://asciinema.org/a/5PhtkWPISVIC4GEUM2Vlg85g1)\n### Brain-calc:\n(https://asciinema.org/a/l2TuoatHFc4Yz9flfU0PNDJek)\n### Brain-gcd:\n(https://asciinema.org/a/W8M5Bzib9COc2rj7fJPyXMLnw)\n### Brain-progression:\n(https://asciinema.org/a/DDGOirXvy8WVJ9D5Mf9Kjz80P)\n### Brain-prime:\n(https://asciinema.org/a/Ex4wKVcW7cNlSRcqG1HqaMvnk)',
    'author': 'Ihar Kostyuchik',
    'author_email': 'kostyuchik22@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/AidDeathLord/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
