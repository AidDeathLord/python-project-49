### Hexlet tests and linter status:
[![Actions Status](https://github.com/AidDeathLord/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AidDeathLord/python-project-49/actions)
<a href="https://codeclimate.com/github/AidDeathLord/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/697cc4e6546ebe8ef998/maintainability" /></a>
