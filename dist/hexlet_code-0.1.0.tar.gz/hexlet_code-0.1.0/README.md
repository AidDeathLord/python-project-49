### Hexlet tests and linter status:
[![Actions Status](https://github.com/AidDeathLord/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AidDeathLord/python-project-49/actions)

### Maintainability:
(<a href="https://codeclimate.com/github/AidDeathLord/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/697cc4e6546ebe8ef998/maintainability" /></a>)

### Asciinema
### Brain-even and install:
(https://asciinema.org/a/5PhtkWPISVIC4GEUM2Vlg85g1)
### Brain-calc:
(https://asciinema.org/a/l2TuoatHFc4Yz9flfU0PNDJek)
### Brain-gcd:
(https://asciinema.org/a/W8M5Bzib9COc2rj7fJPyXMLnw)
### Brain-progression:
(https://asciinema.org/a/DDGOirXvy8WVJ9D5Mf9Kjz80P)
### Brain-prime:
(https://asciinema.org/a/Ex4wKVcW7cNlSRcqG1HqaMvnk)